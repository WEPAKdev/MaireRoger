/*
 * Custom code goes here.
 * A template should always ship with an empty custom.js
 */
$(function(){
    /* change name of tab menu n°2 from ACCUEIL to PRODUITS*/
    var replaced = $("#category-2").html().replace('Acceuil','Produits');
    $("#category-2").html(replaced);
});
